"""
CyberSentinel - Open Source Intrusion Detection System
GitHub: https://github.com/Lord-Jexo/cybersentinel

Features:
- Real-time system monitoring
- Multiple attack vector detection
- Alert notifications (Email, SMS, Dashboard)
- Detailed logging and reporting
- Customizable rules and thresholds
"""

import os
import sys
import time
import logging
import json
import re
import socket
import datetime
import threading
import hashlib
import requests
from pathlib import Path
import subprocess
import signal
import psutil
from flask import Flask, render_template, jsonify, request, Response

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("cybersentinel.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("CyberSentinel")

class Config:
    """Configuration management for CyberSentinel"""
    
    def __init__(self, config_file="config.json"):
        self.config_file = config_file
        self.config = self._load_config()
        
    def _load_config(self):
        """Load configuration from file"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    return json.load(f)
            else:
                # Default configuration
                default_config = {
                    "monitor": {
                        "log_files": [
                            "/var/log/auth.log",
                            "/var/log/syslog",
                            "/var/log/apache2/access.log",
                            "/var/log/apache2/error.log"
                        ],
                        "network": {
                            "interface": "eth0",
                            "scan_interval": 60
                        },
                        "processes": True,
                        "ports": True
                    },
                    "detection": {
                        "signature_path": "signatures/",
                        "threshold": {
                            "failed_login": 5,
                            "port_scan": 10
                        },
                        "scan_frequency": 30,
                        "vuln_db_update": 86400  # Update vulnerability database daily
                    },
                    "notification": {
                        "email": {
                            "enabled": False,
                            "smtp_server": "smtp.gmail.com",
                            "smtp_port": 587,
                            "username": "your-email@gmail.com",
                            "password": "",
                            "recipients": ["admin@example.com"]
                        },
                        "sms": {
                            "enabled": False,
                            "api_key": "",
                            "phone_numbers": ["+123456789"]
                        },
                        "dashboard": {
                            "enabled": True,
                            "port": 8080,
                            "host": "127.0.0.1"
                        }
                    },
                    "response": {
                        "auto_block_ip": False,
                        "auto_kill_process": False
                    }
                }
                
                # Save default config
                with open(self.config_file, 'w') as f:
                    json.dump(default_config, f, indent=4)
                    
                return default_config
                
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
            sys.exit(1)
    
    def get(self, section, key=None):
        """Get configuration value"""
        if key:
            return self.config.get(section, {}).get(key)
        return self.config.get(section, {})
    
    def update(self, section, key, value):
        """Update configuration value"""
        if section not in self.config:
            self.config[section] = {}
        self.config[section][key] = value
        
        with open(self.config_file, 'w') as f:
            json.dump(self.config, f, indent=4)


class SignatureDatabase:
    """Database of attack signatures and vulnerabilities"""
    
    def __init__(self, signature_path):
        self.signature_path = signature_path
        self.signatures = {}
        self.vulnerabilities = {}
        
        # Ensure signature directory exists
        Path(signature_path).mkdir(parents=True, exist_ok=True)
        
        self._load_signatures()
        self._load_vulnerabilities()
    
    def _load_signatures(self):
        """Load attack signatures from files"""
        try:
            signature_file = os.path.join(self.signature_path, "attack_signatures.json")
            if os.path.exists(signature_file):
                with open(signature_file, 'r') as f:
                    self.signatures = json.load(f)
            else:
                # Default basic signatures
                self.signatures = {
                    "bruteforce": {
                        "pattern": r"Failed password for .* from .* port \d+",
                        "description": "Brute force login attempt",
                        "severity": "high"
                    },
                    "sql_injection": {
                        "pattern": r"[\"'`;](?:\s*(?:union|select|insert|update|delete|drop|alter))",
                        "description": "SQL Injection attempt",
                        "severity": "critical"
                    },
                    "xss": {
                        "pattern": r"<script\b[^>]*>[^<]*<\/script>|<[^>]*onload=|javascript:",
                        "description": "Cross-site scripting (XSS) attempt",
                        "severity": "high"
                    },
                    "port_scan": {
                        "pattern": r"SYN scan",
                        "description": "Port scanning activity",
                        "severity": "medium"
                    },
                    "command_injection": {
                        "pattern": r"[;|&](?:\s*[^\w\s]?\s*(?:cat|ls|pwd|whoami|echo|bash|sh))",
                        "description": "Command injection attempt",
                        "severity": "critical"
                    },
                    "file_inclusion": {
                        "pattern": r"[?&](?:\w+)=(?:https?:)?[/\\]{2,}|[.]{2,}[/\\]",
                        "description": "Local/Remote file inclusion attempt",
                        "severity": "high"
                    }
                }
                
                # Save default signatures
                with open(signature_file, 'w') as f:
                    json.dump(self.signatures, f, indent=4)
                    
        except Exception as e:
            logger.error(f"Error loading attack signatures: {e}")
    
    def _load_vulnerabilities(self):
        """Load vulnerability database"""
        try:
            vuln_file = os.path.join(self.signature_path, "vulnerabilities.json")
            if os.path.exists(vuln_file):
                with open(vuln_file, 'r') as f:
                    self.vulnerabilities = json.load(f)
            else:
                # Initialize empty vulnerability database
                self.vulnerabilities = {
                    "last_updated": "",
                    "cve_list": {}
                }
                
                # Save empty vulnerability database
                with open(vuln_file, 'w') as f:
                    json.dump(self.vulnerabilities, f, indent=4)
                    
        except Exception as e:
            logger.error(f"Error loading vulnerabilities database: {e}")
    
    def update_vulnerabilities(self):
        """Update vulnerability database from online sources"""
        try:
            logger.info("Updating vulnerability database...")
            
            # In a real implementation, you would fetch from NVD or other sources
            # For this demo, we'll just update the timestamp
            self.vulnerabilities["last_updated"] = datetime.datetime.now().isoformat()
            
            # Add some example vulnerabilities
            self.vulnerabilities["cve_list"]["CVE-2023-12345"] = {
                "description": "Buffer overflow in OpenSSH",
                "severity": "high",
                "affected_software": ["OpenSSH 8.5", "OpenSSH 8.6"],
                "remediation": "Update to OpenSSH 8.7 or later"
            }
            
            # Save updated vulnerabilities
            vuln_file = os.path.join(self.signature_path, "vulnerabilities.json")
            with open(vuln_file, 'w') as f:
                json.dump(self.vulnerabilities, f, indent=4)
                
            logger.info("Vulnerability database updated successfully")
            
        except Exception as e:
            logger.error(f"Error updating vulnerability database: {e}")
    
    def add_signature(self, name, pattern, description, severity):
        """Add a new attack signature"""
        try:
            self.signatures[name] = {
                "pattern": pattern,
                "description": description,
                "severity": severity
            }
            
            # Save updated signatures
            signature_file = os.path.join(self.signature_path, "attack_signatures.json")
            with open(signature_file, 'w') as f:
                json.dump(self.signatures, f, indent=4)
                
            logger.info(f"Added new signature: {name}")
            return True
            
        except Exception as e:
            logger.error(f"Error adding new signature: {e}")
            return False


class LogMonitor:
    """Monitor system log files for suspicious activities"""
    
    def __init__(self, config, signature_db):
        self.config = config
        self.signature_db = signature_db
        self.log_files = config.get("monitor", {}).get("log_files", [])
        self.file_positions = {}
        
        # Initialize file positions
        for log_file in self.log_files:
            if os.path.exists(log_file):
                self.file_positions[log_file] = os.path.getsize(log_file)
    
    def check_logs(self):
        """Check log files for new entries and analyze them"""
        findings = []
        
        for log_file in self.log_files:
            if not os.path.exists(log_file):
                continue
                
            try:
                file_size = os.path.getsize(log_file)
                
                # If file size decreased (log rotation), start from beginning
                if log_file in self.file_positions and file_size < self.file_positions[log_file]:
                    self.file_positions[log_file] = 0
                
                if log_file not in self.file_positions:
                    self.file_positions[log_file] = file_size
                    continue
                
                # If file hasn't changed, skip
                if file_size == self.file_positions[log_file]:
                    continue
                
                # Read new content
                with open(log_file, 'r') as f:
                    f.seek(self.file_positions[log_file])
                    new_content = f.read()
                
                # Update file position
                self.file_positions[log_file] = file_size
                
                # Analyze new content
                for line in new_content.splitlines():
                    for sig_name, signature in self.signature_db.signatures.items():
                        pattern = signature["pattern"]
                        if re.search(pattern, line, re.IGNORECASE):
                            # Create finding
                            finding = {
                                "timestamp": datetime.datetime.now().isoformat(),
                                "source": log_file,
                                "type": sig_name,
                                "description": signature["description"],
                                "severity": signature["severity"],
                                "data": line,
                                "source_ip": self._extract_ip(line)
                            }
                            findings.append(finding)
                            
            except Exception as e:
                logger.error(f"Error monitoring log file {log_file}: {e}")
        
        return findings
    
    def _extract_ip(self, text):
        """Extract IP address from text if present"""
        ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
        match = re.search(ip_pattern, text)
        return match.group(0) if match else None


class NetworkMonitor:
    """Monitor network for suspicious activities"""
    
    def __init__(self, config):
        self.config = config
        self.interface = config.get("monitor", {}).get("network", {}).get("interface", "eth0")
        self.scan_interval = config.get("monitor", {}).get("network", {}).get("scan_interval", 60)
        self.open_connections = {}
    
    def check_network(self):
        """Check network for suspicious activities"""
        findings = []
        
        try:
            # Get current connections
            connections = psutil.net_connections(kind='inet')
            current_connections = {}
            
            for conn in connections:
                if conn.status == 'ESTABLISHED' and conn.raddr:
                    ip, port = conn.raddr
                    key = f"{ip}:{port}"
                    current_connections[key] = {
                        "ip": ip,
                        "port": port,
                        "pid": conn.pid,
                        "process": self._get_process_name(conn.pid) if conn.pid else "Unknown"
                    }
            
            # Check for new connections
            for key, conn in current_connections.items():
                if key not in self.open_connections:
                    # New connection
                    finding = {
                        "timestamp": datetime.datetime.now().isoformat(),
                        "source": "network_monitor",
                        "type": "new_connection",
                        "description": f"New network connection established",
                        "severity": "info",
                        "data": {
                            "ip": conn["ip"],
                            "port": conn["port"],
                            "process": conn["process"],
                            "pid": conn["pid"]
                        },
                        "source_ip": conn["ip"]
                    }
                    findings.append(finding)
            
            # Update open connections
            self.open_connections = current_connections
            
            # Check for unusual ports
            unusual_ports = self._check_unusual_ports()
            findings.extend(unusual_ports)
            
        except Exception as e:
            logger.error(f"Error monitoring network: {e}")
        
        return findings
    
    def _get_process_name(self, pid):
        """Get process name from PID"""
        try:
            process = psutil.Process(pid)
            return process.name()
        except:
            return "Unknown"
    
    def _check_unusual_ports(self):
        """Check for unusual open ports"""
        findings = []
        
        try:
            unusual_ports = {
                22: "SSH",
                23: "Telnet",
                445: "SMB",
                1433: "MSSQL",
                3306: "MySQL",
                3389: "RDP",
                5432: "PostgreSQL",
                6379: "Redis"
            }
            
            for conn in psutil.net_connections(kind='inet'):
                if conn.status == 'LISTEN' and conn.laddr.port in unusual_ports:
                    service = unusual_ports[conn.laddr.port]
                    
                    finding = {
                        "timestamp": datetime.datetime.now().isoformat(),
                        "source": "network_monitor",
                        "type": "unusual_port",
                        "description": f"Sensitive service {service} is exposed",
                        "severity": "medium",
                        "data": {
                            "port": conn.laddr.port,
                            "service": service,
                            "process": self._get_process_name(conn.pid) if conn.pid else "Unknown",
                            "pid": conn.pid
                        },
                        "source_ip": "127.0.0.1"  # Local system
                    }
                    findings.append(finding)
                    
        except Exception as e:
            logger.error(f"Error checking unusual ports: {e}")
        
        return findings


class ProcessMonitor:
    """Monitor system processes for suspicious activities"""
    
    def __init__(self, config):
        self.config = config
        self.processes = {}
    
    def check_processes(self):
        """Check for suspicious processes"""
        findings = []
        
        try:
            current_processes = {}
            
            for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'username', 'create_time']):
                try:
                    process_info = proc.info
                    pid = process_info['pid']
                    
                    current_processes[pid] = {
                        "name": process_info['name'],
                        "cmdline": process_info['cmdline'],
                        "username": process_info['username'],
                        "create_time": process_info['create_time']
                    }
                    
                    # Check for new processes
                    if pid not in self.processes:
                        # New process
                        finding = {
                            "timestamp": datetime.datetime.now().isoformat(),
                            "source": "process_monitor",
                            "type": "new_process",
                            "description": f"New process started: {process_info['name']}",
                            "severity": "info",
                            "data": current_processes[pid],
                            "source_ip": "127.0.0.1"  # Local system
                        }
                        findings.append(finding)
                        
                        # Check if process is suspicious
                        if self._is_suspicious_process(current_processes[pid]):
                            finding = {
                                "timestamp": datetime.datetime.now().isoformat(),
                                "source": "process_monitor",
                                "type": "suspicious_process",
                                "description": f"Suspicious process detected: {process_info['name']}",
                                "severity": "high",
                                "data": current_processes[pid],
                                "source_ip": "127.0.0.1"  # Local system
                            }
                            findings.append(finding)
                    
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    pass
            
            # Check for terminated processes
            for pid in list(self.processes.keys()):
                if pid not in current_processes:
                    # Process terminated
                    finding = {
                        "timestamp": datetime.datetime.now().isoformat(),
                        "source": "process_monitor",
                        "type": "process_terminated",
                        "description": f"Process terminated: {self.processes[pid]['name']}",
                        "severity": "info",
                        "data": self.processes[pid],
                        "source_ip": "127.0.0.1"  # Local system
                    }
                    findings.append(finding)
            
            # Update processes
            self.processes = current_processes
            
        except Exception as e:
            logger.error(f"Error monitoring processes: {e}")
        
        return findings
    
    def _is_suspicious_process(self, process):
        """Check if process is suspicious"""
        suspicious_names = [
            "nc", "netcat", "nmap", "wireshark", "tcpdump", "john", "hydra",
            "hashcat", "mimikatz", "pwdump", "responder", "metasploit"
        ]
        
        # Check process name
        if process["name"].lower() in suspicious_names:
            return True
        
        # Check command line for suspicious arguments
        if process["cmdline"]:
            cmdline = " ".join(process["cmdline"]).lower()
            suspicious_args = [
                "--password", "bruteforce", "crack", "exploit", "payload",
                "reverse shell", "bind shell", "backdoor"
            ]
            
            for arg in suspicious_args:
                if arg in cmdline:
                    return True
        
        return False


class FileSystemMonitor:
    """Monitor file system for suspicious activities"""
    
    def __init__(self, config):
        self.config = config
        self.sensitive_dirs = [
            "/etc/",
            "/var/www/",
            "/home/",
            "/usr/bin/",
            "/usr/sbin/",
            "/bin/",
            "/sbin/"
        ]
        self.file_hashes = {}
        
        # Initialize file hashes
        self._initialize_file_hashes()
    
    def _initialize_file_hashes(self):
        """Initialize file hashes for sensitive files"""
        sensitive_files = [
            "/etc/passwd",
            "/etc/shadow",
            "/etc/hosts",
            "/etc/sudoers",
            "/etc/ssh/sshd_config"
        ]
        
        for file_path in sensitive_files:
            if os.path.exists(file_path):
                try:
                    self.file_hashes[file_path] = self._calculate_file_hash(file_path)
                except Exception as e:
                    logger.error(f"Error calculating hash for {file_path}: {e}")
    
    def _calculate_file_hash(self, file_path):
        """Calculate SHA-256 hash of a file"""
        hash_obj = hashlib.sha256()
        
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b''):
                hash_obj.update(chunk)
        
        return hash_obj.hexdigest()
    
    def check_files(self):
        """Check for suspicious file activities"""
        findings = []
        
        # Check sensitive files for modifications
        for file_path, stored_hash in self.file_hashes.items():
            if os.path.exists(file_path):
                try:
                    current_hash = self._calculate_file_hash(file_path)
                    
                    if current_hash != stored_hash:
                        # File modified
                        finding = {
                            "timestamp": datetime.datetime.now().isoformat(),
                            "source": "filesystem_monitor",
                            "type": "file_modified",
                            "description": f"Sensitive file modified: {file_path}",
                            "severity": "high",
                            "data": {
                                "file_path": file_path,
                                "old_hash": stored_hash,
                                "new_hash": current_hash
                            },
                            "source_ip": "127.0.0.1"  # Local system
                        }
                        findings.append(finding)
                        
                        # Update hash
                        self.file_hashes[file_path] = current_hash
                        
                except Exception as e:
                    logger.error(f"Error checking file {file_path}: {e}")
        
        return findings


class AlertManager:
    """Manage and send alerts for detected issues"""
    
    def __init__(self, config):
        self.config = config
        self.alert_history = []
    
    def process_findings(self, findings):
        """Process findings and generate alerts"""
        for finding in findings:
            # Add to history
            self.alert_history.append(finding)
            
            # Log the finding
            severity = finding["severity"].upper()
            logger.warning(f"[{severity}] {finding['description']} - {finding['source']}")
            
            # Send notifications based on severity
            if finding["severity"] in ["high", "critical"]:
                self._send_notifications(finding)
    
    def _send_notifications(self, finding):
        """Send notifications for critical findings"""
        # Email notification
        if self.config.get("notification", {}).get("email", {}).get("enabled", False):
            self._send_email_notification(finding)
        
        # SMS notification
        if self.config.get("notification", {}).get("sms", {}).get("enabled", False):
            self._send_sms_notification(finding)
        
        # Take automated response if configured
        self._take_automated_response(finding)
    
    def _send_email_notification(self, finding):
        """Send email notification"""
        try:
            email_config = self.config.get("notification", {}).get("email", {})
            
            # In a real implementation, you would use smtplib to send emails
            logger.info(f"Email notification would be sent to {email_config['recipients']}")
            
        except Exception as e:
            logger.error(f"Error sending email notification: {e}")
    
    def _send_sms_notification(self, finding):
        """Send SMS notification"""
        try:
            sms_config = self.config.get("notification", {}).get("sms", {})
            
            # In a real implementation, you would use a service like Twilio
            logger.info(f"SMS notification would be sent to {sms_config['phone_numbers']}")
            
        except Exception as e:
            logger.error(f"Error sending SMS notification: {e}")
    
    def _take_automated_response(self, finding):
        """Take automated response based on finding"""
        response_config = self.config.get("response", {})
        
        # Block IP
        if response_config.get("auto_block_ip", False) and finding.get("source_ip"):
            ip = finding["source_ip"]
            logger.info(f"Would block IP: {ip}")
            
            # In a real implementation, you would use iptables or similar
            # subprocess.run(["iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"])
        
        # Kill process
        if response_config.get("auto_kill_process", False) and finding.get("type") == "suspicious_process":
            pid = finding["data"].get("pid")
            if pid:
                logger.info(f"Would kill process: {pid}")
                
                # In a real implementation:
                # os.kill(pid, signal.SIGTERM)


class Dashboard:
    """Web dashboard for CyberSentinel"""
    
    def __init__(self, config, alert_manager):
        self.config = config
        self.alert_manager = alert_manager
        self.dashboard_config = config.get("notification", {}).get("dashboard", {})
        self.enabled = self.dashboard_config.get("enabled", True)
        self.port = self.dashboard_config.get("port", 8080)
        self.host = self.dashboard_config.get("host", "127.0.0.1")
        self.app = None
        
        if self.enabled:
            self._start_dashboard()
    
    def _start_dashboard(self):
        """Start the dashboard web server"""
        try:
            self.app = Flask(__name__)
            
            @self.app.route('/')
            def index():
                return render_template('index.html')
            
            @self.app.route('/api/alerts')
            def alerts():
                return jsonify(self.alert_manager.alert_history)
            
            @self.app.route('/api/system')
            def system_info():
                return jsonify({
                    "cpu": psutil.cpu_percent(interval=1),
                    "memory": psutil.virtual_memory().percent,
                    "disk": psutil.disk_usage('/').percent,
                    "uptime": int(time.time() - psutil.boot_time())
                })
            
            @self.app.route('/api/network')
            def network_info():
                connections = psutil.net_connections(kind='inet')
                established = [conn for conn in connections if conn.status == 'ESTABLISHED']
                
                return jsonify({
                    "total_connections": len(connections),
                    "established_connections": len(established)
                })
            
            # Start Flask in a separate thread
            def run_flask_app():
                self.app.run(host=self.host, port=self.port, debug=False, use_reloader=False)
            
            flask_thread = threading.Thread(target=run_flask_app, daemon=True)
            flask_thread.start()
            
            logger.info(f"Dashboard started at http://{self.host}:{self.port}")
            
        except Exception as e:
            logger.error(f"Error starting dashboard: {e}")


class CyberSentinel:
    """Main CyberSentinel IDS application"""
    
    def __init__(self):
        self.config = Config()
        self.signature_db = SignatureDatabase(self.config.get("detection", {}).get("signature_path", "signatures/"))
        self.log_monitor = LogMonitor(self.config, self.signature_db)
        self.network_monitor = NetworkMonitor(self.config)
        self.process_monitor = ProcessMonitor(self.config)
        self.filesystem_monitor = FileSystemMonitor(self.config)
        self.alert_manager = AlertManager(self.config)
        self.dashboard = Dashboard(self.config, self.alert_manager)
        
        self.running = False
        self.last_vuln_update = 0
    
    def start(self):
        """Start the IDS"""
        self.running = True
        logger.info("CyberSentinel IDS starting...")
        
        try:
            while self.running:
                # Check for updates to vulnerability database
                vuln_update_interval = self.config.get("detection", {}).get("vuln_db_update", 86400)
                current_time = time.time()
                
                if current_time - self.last_vuln_update > vuln_update_interval:
                    self.signature_db.update_vulnerabilities()
                    self.last_vuln_update = current_time
                
                # Run all monitors
                findings = []
                
                # Log monitor
                log_findings = self.log_monitor.check_logs()
                findings.extend(log_findings)
                
                # Network monitor
                network_findings = self.network_monitor.check_network()
                findings.extend(network_findings)
                
                # Process monitor
                process_findings = self.process_monitor.check_processes()
                findings.extend(process_findings)
                
                # Filesystem monitor
                filesystem_findings = self.filesystem_monitor.check_files()
                findings.extend(filesystem_findings)
                
                # Process findings
                if findings:
                    self.alert_manager.process_findings(findings)
                
                # Sleep for scan interval
                scan_interval = self.config.get("detection", {}).get("scan_frequency", 30)
                time.sleep(scan_interval)
                
        except KeyboardInterrupt:
            logger.info("CyberSentinel IDS stopping...")
            self.running = False
        except Exception as e:
            logger.error(f"Error in main loop: {e}")
            self.running = False


if __name__ == "__main__":
    print("""
    ╔═══════════════════════════════════════════╗
    ║           CyberSentinel IDS               ║
    ║     Open Source Intrusion Detection       ║
    ╚═══════════════════════════════════════════╝
    """)
    
    # Ensure templates directory exists
    templates_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates")
    Path(templates_dir).mkdir(parents=True, exist_ok=True)
    
    # Ensure static directory exists
    static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
    Path(static_dir).mkdir(parents=True, exist_ok=True)
    Path(os.path.join(static_dir, "css")).mkdir(parents=True, exist_ok=True)
    Path(os.path.join(static_dir, "js")).mkdir(parents=True, exist_ok=True)
    
    ids = CyberSentinel()
    ids.start()