// CyberSentinel IDS Dashboard JavaScript

// Initialize tooltips
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize charts
    initCharts();
    
    // Start data refresh
    refreshData();
    setInterval(refreshData, 5000); // Refresh every 5 seconds
});

// Security Chart initialization
function initCharts() {
    // Security metrics chart
    var securityCtx = document.getElementById('security-chart').getContext('2d');
    var securityChart = new Chart(securityCtx, {
        type: 'bar',
        data: {
            labels: ['Brute Force', 'SQL Injection', 'XSS', 'Port Scan', 'Command Inject', 'File Inclusion'],
            datasets: [{
                label: 'Attack Attempts',
                data: [12, 4, 8, 15, 3, 6],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.7)',
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(255, 206, 86, 0.7)',
                    'rgba(75, 192, 192, 0.7)',
                    'rgba(153, 102, 255, 0.7)',
                    'rgba(255, 159, 64, 0.7)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Attack Attempts by Type (Last 24 Hours)'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Vulnerability chart
    var vulnCtx = document.getElementById('vuln-chart').getContext('2d');
    var vulnChart = new Chart(vulnCtx, {
        type: 'doughnut',
        data: {
            labels: ['Critical', 'High', 'Medium', 'Low'],
            datasets: [{
                label: 'Vulnerabilities',
                data: [4, 7, 12, 5],
                backgroundColor: [
                    'rgba(220, 53, 69, 0.8)',
                    'rgba(253, 126, 20, 0.8)',
                    'rgba(255, 193, 7, 0.8)',
                    'rgba(23, 162, 184, 0.8)'
                ],
                borderColor: [
                    'rgba(220, 53, 69, 1)',
                    'rgba(253, 126, 20, 1)',
                    'rgba(255, 193, 7, 1)',
                    'rgba(23, 162, 184, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'right',
                },
                title: {
                    display: true,
                    text: 'Vulnerabilities by Severity'
                }
            }
        }
    });
}

// Fetch and update data
function refreshData() {
    // Update system info
    fetchSystemInfo();
    
    // Update alerts
    fetchAlerts();
}

// Fetch system information
function fetchSystemInfo() {
    // In a real implementation, this would make an API call
    // For demo, we'll simulate with random data
    fetch('/api/system')
        .then(response => response.json())
        .then(data => {
            document.getElementById('cpu-usage').textContent = data.cpu + '%';
            document.getElementById('memory-usage').textContent = data.memory + '%';
            document.getElementById('disk-usage').textContent = data.disk + '%';
            
            // Format uptime
            const uptime = formatUptime(data.uptime);
            
            // Update security status based on system metrics
            updateSecurityStatus(data);
        })
        .catch(error => {
            console.error('Error fetching system info:', error);
            // For demo, use random values
            document.getElementById('cpu-usage').textContent = Math.floor(Math.random() * 100) + '%';
            document.getElementById('memory-usage').textContent = Math.floor(Math.random() * 100) + '%';
            document.getElementById('disk-usage').textContent = Math.floor(Math.random() * 100) + '%';
            
            // Use simulated data for security status
            updateSecurityStatus({
                cpu: Math.floor(Math.random() * 100),
                memory: Math.floor(Math.random() * 100),
                disk: Math.floor(Math.random() * 100)
            });
        });
        
    // Get network info
    fetch('/api/network')
        .then(response => response.json())
        .then(data => {
            document.getElementById('network-connections').textContent = data.established_connections;
        })
        .catch(error => {
            console.error('Error fetching network info:', error);
            // For demo, use random values
            document.getElementById('network-connections').textContent = Math.floor(Math.random() * 50);
        });
}

// Format uptime in days, hours, minutes
function formatUptime(seconds) {
    const days = Math.floor(seconds / (3600 * 24));
    const hours = Math.floor((seconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    return `${days}d ${hours}h ${minutes}m`;
}

// Update security status indicator
function updateSecurityStatus(data) {
    const securityStatus = document.getElementById('security-status');
    
    // Simple logic for demo
    if (data.cpu > 90 || data.memory > 90) {
        securityStatus.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i> <strong>System Stress Detected!</strong> High resource usage may indicate an attack in progress.
            </div>
        `;
    } else if (data.cpu > 70 || data.memory > 70) {
        securityStatus.innerHTML = `
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle me-2"></i> <strong>Elevated Resource Usage!</strong> System is experiencing higher than normal load.
            </div>
        `;
    } else {
        securityStatus.innerHTML = `
            <div class="alert alert-success">
                <i class="fas fa-shield-alt me-2"></i> <strong>System Secure!</strong> All monitors are running normally.
            </div>
        `;
    }
}

// Fetch and update alerts
function fetchAlerts() {
    fetch('/api/alerts')
        .then(response => response.json())
        .then(data => {
            updateAlertsTable(data);
            updateAlertsContainer(data);
        })
        .catch(error => {
            console.error('Error fetching alerts:', error);
            // For demo, generate random sample alerts
            const sampleAlerts = generateSampleAlerts();
            updateAlertsTable(sampleAlerts);
            updateAlertsContainer(sampleAlerts);
        });
}

// Update alerts table
function updateAlertsTable(alerts) {
    const tableBody = document.getElementById('alerts-table-body');
    
    // Sort alerts by timestamp (newest first)
    const sortedAlerts = [...alerts].sort((a, b) => {
        return new Date(b.timestamp) - new Date(a.timestamp);
    });
    
    // Take only the most recent 10 alerts
    const recentAlerts = sortedAlerts.slice(0, 10);
    
    // Clear existing rows
    tableBody.innerHTML = '';
    
    // Add new rows
    if (recentAlerts.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="7" class="text-center">No alerts found</td>
            </tr>
        `;
    } else {
        recentAlerts.forEach(alert => {
            const row = document.createElement('tr');
            
            // Set row class based on severity
            if (alert.severity === 'critical') {
                row.classList.add('table-danger');
            } else if (alert.severity === 'high') {
                row.classList.add('table-warning');
            }
            
            // Format the timestamp
            const timestamp = new Date(alert.timestamp);
            const formattedTime = timestamp.toLocaleString();
            
            row.innerHTML = `
                <td>${formattedTime}</td>
                <td>${alert.source}</td>
                <td>${alert.type}</td>
                <td>${alert.description}</td>
                <td><span class="badge bg-${getSeverityColor(alert.severity)}">${alert.severity.toUpperCase()}</span></td>
                <td>${alert.source_ip || 'N/A'}</td>
                <td>
                    <button class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="View Details"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Block IP"><i class="fas fa-ban"></i></button>
                </td>
            `;
            
            tableBody.appendChild(row);
        });
    }
    
    // Reinitialize tooltips for the new buttons
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Update alerts container
function updateAlertsContainer(alerts) {
    const container = document.getElementById('alerts-container');
    
    // Sort alerts by timestamp (newest first)
    const sortedAlerts = [...alerts].sort((a, b) => {
        return new Date(b.timestamp) - new Date(a.timestamp);
    });
    
    // Take only the most recent 5 critical/high alerts
    const criticalAlerts = sortedAlerts.filter(alert => 
        alert.severity === 'critical' || alert.severity === 'high'
    ).slice(0, 5);
    
    // Clear existing alerts
    container.innerHTML = '';
    
    // Add new alerts
    if (criticalAlerts.length === 0) {
        container.innerHTML = `
            <div class="text-center text-muted">
                <i class="fas fa-check-circle fa-3x mb-3"></i>
                <p>No critical alerts at this time</p>
            </div>
        `;
    } else {
        criticalAlerts.forEach(alert => {
            const alertDiv = document.createElement('div');
            alertDiv.classList.add('alert-item', alert.severity);
            
            // Format the timestamp
            const timestamp = new Date(alert.timestamp);
            const formattedTime = timestamp.toLocaleString();
            
            alertDiv.innerHTML = `
                <div class="d-flex justify-content-between">
                    <strong>${alert.description}</strong>
                    <span class="badge bg-${getSeverityColor(alert.severity)}">${alert.severity.toUpperCase()}</span>
                </div>
                <div class="text-muted small">${formattedTime}</div>
                <div class="mt-1">Source: ${alert.source}</div>
                ${alert.source_ip ? `<div>IP: ${alert.source_ip}</div>` : ''}
            `;
            
            container.appendChild(alertDiv);
        });
    }
}

// Get Bootstrap color class based on severity
function getSeverityColor(severity) {
    switch (severity.toLowerCase()) {
        case 'critical':
            return 'danger';
        case 'high':
            return 'warning';
        case 'medium':
            return 'primary';
        case 'low':
            return 'info';
        case 'info':
            return 'secondary';
        default:
            return 'secondary';
    }
}

// Generate sample alerts for demo
function generateSampleAlerts() {
    const alertTypes = [
        { type: 'bruteforce', description: 'Brute force login attempt', severity: 'high' },
        { type: 'sql_injection', description: 'SQL Injection attempt', severity: 'critical' },
        { type: 'xss', description: 'Cross-site scripting (XSS) attempt', severity: 'high' },
        { type: 'port_scan', description: 'Port scanning activity', severity: 'medium' },
        { type: 'command_injection', description: 'Command injection attempt', severity: 'critical' },
        { type: 'file_inclusion', description: 'Local/Remote file inclusion attempt', severity: 'high' },
        { type: 'new_process', description: 'New process started', severity: 'info' },
        { type: 'new_connection', description: 'New network connection established', severity: 'info' },
        { type: 'unusual_port', description: 'Sensitive service is exposed', severity: 'medium' },
        { type: 'file_modified', description: 'Sensitive file modified', severity: 'high' }
    ];
    
    const sources = [
        'log_monitor',
        'network_monitor',
        'process_monitor',
        'filesystem_monitor'
    ];
    
    const ipAddresses = [
        '192.168.1.100',
        '10.0.0.15',
        '172.16.0.32',
        '203.0.113.45',
        '198.51.100.78',
        '8.8.8.8',
        '1.1.1.1'
    ];
    
    const sampleAlerts = [];
    
    // Generate between 5-15 random alerts
    const numAlerts = Math.floor(Math.random() * 10) + 5;
    
    for (let i = 0; i < numAlerts; i++) {
        const alertType = alertTypes[Math.floor(Math.random() * alertTypes.length)];
        const source = sources[Math.floor(Math.random() * sources.length)];
        const ip = ipAddresses[Math.floor(Math.random() * ipAddresses.length)];
        
        // Generate a random timestamp from the last 24 hours
        const date = new Date();
        date.setHours(date.getHours() - Math.floor(Math.random() * 24));
        date.setMinutes(date.getMinutes() - Math.floor(Math.random() * 60));
        
        sampleAlerts.push({
            timestamp: date.toISOString(),
            source: source,
            type: alertType.type,
            description: alertType.description,
            severity: alertType.severity,
            data: {},
            source_ip: ip
        });
    }
    
    return sampleAlerts;
}